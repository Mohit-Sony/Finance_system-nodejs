module.exports.login = function(req,res){
    return res.render('login');
}