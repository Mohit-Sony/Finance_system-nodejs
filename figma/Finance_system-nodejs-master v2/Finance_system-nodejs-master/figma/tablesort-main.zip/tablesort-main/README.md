# tablesort

Created in trying to replace https://joequery.github.io/Stupid-Table-Plugin/ on jQuery-less website

No defence against complicated THEADs or very large tables
