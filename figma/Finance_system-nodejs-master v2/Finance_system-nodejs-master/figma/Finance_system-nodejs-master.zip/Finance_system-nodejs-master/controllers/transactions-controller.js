module.exports.list = function(req,res){
    res.render('transactions');
}